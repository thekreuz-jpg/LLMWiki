---
name: hermes-windows-config
description: "Windows-specific Hermes configuration: workspace path gotchas, Docker backend setup, and remote gateway access for the desktop app."
version: 1.0.0
author: Hermes Agent + Kreuz
license: MIT
platforms: [windows]
metadata:
  hermes:
    tags: [windows, config, docker, gateway, remote]
---

# Hermes Windows Config

Windows-specific Hermes setup behaviors that are not obvious from the docs.

## Workspace path resolution

When `terminal.cwd` is set to `/workspace` in `config.yaml`, on Windows under the bundled git-bash/MSYS environment this path does **not** resolve to `C:\Users\<user>\workspace`. Instead, it often resolves relative to the Hermes git checkout:

```
C:\Users\Kreuz\AppData\Local\hermes\git\workspace
```

### Verify the real path
```bash
pwd
cygpath -w /workspace
```

### Fix
Either create the directory in the resolved location, or set `terminal.cwd` to an explicit Windows-style path such as `C:/Users/Kreuz/workspace`.

## Docker backend

### Prerequisites
- Docker Desktop for Windows with WSL 2 backend.

### Config change
```yaml
terminal:
  backend: docker
  cwd: /workspace     # must exist inside container or be mounted
  docker_mount_cwd_to_workspace: false
```

### Run example
```bash
docker build -t hermes-agent .
docker run -it --rm \
  -v "C:\Users\Kreuz\AppData\Local\hermes:C:\Users\Kreuz\AppData\Local\hermes" \
  -v "C:\Users\Kreuz\workspace:/workspace" \
  -e HERMES_HOME=C:\Users\Kreuz\AppData\Local\hermes \
  hermes-agent
```

## Python PATH ambiguity on Windows (local terminal backend)

When `terminal.backend` is `local`, `python` may resolve to Hermes's bundled venv interpreter before any system Python. If a tool requires a newer Python version, the version-gate failure will still reference an older system interpreter even after installing a newer one.

### Why it happens
- `where python` returns Hermes's venv first.
- A fresh `terminal()` shell does not inherit env files by default.
- Writing `LAST30DAYS_PYTHON=...` to `~/.config/last30days/.env` does not automatically populate the next shell's environment.

### Fix
Use the explicit Windows interpreter path instead of relying on PATH or env files:

```powershell
# Verify what python resolves to
where python

# Locate installed versions
py -0

# Explicit invocation for tools requiring Python 3.12+
& 'C:\Users\Kreuz\AppData\Local\Programs\Python\Python312\python.exe' script.py
```

Make it the default invocation path for any skill or tool that hard-fails its Python version gate despite a newer install being present.

## last30days Windows setup

This skill's Windows quirks are significant enough to call out explicitly:

### First-run gate requires `SETUP_COMPLETE=true`
The `last30days` first-run check is a literal grep for `SETUP_COMPLETE=true` in `~/.config/last30days/.env`:
```bash
grep -q "SETUP_COMPLETE=true" ~/.config/last30days/.env 2>/dev/null && echo "1" || echo "FIRST_RUN_DETECTED"
```
Without that exact line, setup treats every run as a first run and forces the full browser-cookie wizard.

### `.env` must be `KEY=VALUE`, not cookie JSON
If you paste the raw cookie JSON array exported from the browser, the skill will not parse it. Use this shape:
```env
SETUP_COMPLETE=true
AUTH_TOKEN=***
CT0=***
```

### Python 3.12+ interpreter
The engine requires Python 3.12+. On Windows, the default `python` may resolve to an older venv, so explicitly invoke:
```bash
/c/Users/Kreuz/AppData/Local/Programs/Python/Python312/python.exe
```
and export `LAST30DAYS_PYTHON` to that path for the invocation.

### Save-dir path behavior under git-bash/MSYS
Saved artifacts may appear under a `/c/Users/Kreuz/.config/last30days/...` style path rather than a clean Windows path. This does not break execution, but be aware that the on-disk path shown in output may start with `/c/`.

## Remote gateway / desktop app

The Hermes desktop app can drive a remote Hermes instance via per-profile remote-gateway login.

### Requirements
1. Gateway service running on the host: `hermes gateway run` or `hermes gateway install && hermes gateway start`
2. The gateway must be exposed on the LAN. Check config for bind address/port or forward with your tunnel/firewall rule.
3. Strong auth set on the profile.
4. On the remote PC, install the Hermes desktop app and use its remote-gateway login flow to point it at the host gateway.

## Browser-based login limits (X/Twitter)

Cookies exported from the browser cannot fully restore authenticated sessions inside Hermes's browser tool.

### Why direct cookie import fails
- `auth_token` is `httpOnly`
- `__cf_bm` is `httpOnly`
These are set by the server and cannot be written from JavaScript via `document.cookie`, so pasted cookie JSON will not make a browser session authenticated.

### Confirmed behavior
- Loading `x.com` in the Hermes browser shows the login form
- Non-`httpOnly` cookies can be set via JS, but the critical session cookies cannot
- An API probe from the browser session without proper cookies will not authenticate

### Practical workaround on Windows
Do not attempt browser automation login. Instead:
- Export `auth_token` and `ct0` from your logged-in browser
- Provide them to CLI-capable tools via `.env` files or environment variables
- For `last30days` specifically, write them to `C:\Users\Kreuz\.config\last30days\.env` as `AUTH_TOKEN=...` and `CT0=...`
- For X automation, use a tool/library that accepts raw cookies directly rather than relying on browser cookie stores
